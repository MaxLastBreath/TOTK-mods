TotK DynamicFPS 1.5.4beta6 by /u/ChucksFeedAndSeed
Check https://www.reddit.com/user/ChucksFeedAndSeed/ for updates.

To enable DynamicFPS make sure the "DynamicFPS - #1-0 - v1.5.4 (Main)" mod folder is enabled in your emulator.
With that enabled you can then enable the extra mods marked (Optional) to configure it as you like.

---

If you'd like to support my work I have a ko-fi page at https://ko-fi.com/ChucksFeedAndSeed :)
